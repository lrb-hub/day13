package com.xiaoshu.entity;

public class DeptVo extends Dept {
	
	private String orderByClause;

	public String getOrderByClause() {
		return orderByClause;
	}

	public void setOrderByClause(String orderByClause) {
		this.orderByClause = orderByClause;
	}
	
}
